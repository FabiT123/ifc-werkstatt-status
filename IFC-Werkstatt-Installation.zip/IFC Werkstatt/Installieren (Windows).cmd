@echo off
title IFC Werkstatt installieren
if not exist "%~dp0setup\install.ps1" (
  echo.
  echo  Bitte die ZIP-Datei zuerst entpacken:
  echo  Rechtsklick auf die ZIP-Datei ^> "Alle extrahieren", dann diese Datei im entpackten Ordner starten.
  echo.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
if errorlevel 1 (
  echo.
  echo  Die Installation konnte nicht abgeschlossen werden.
  echo  Alternative ohne Installation: Die Datei "app\IFC-Werkstatt.html" per Doppelklick oeffnen.
  echo.
  pause
)
