﻿# Deinstallation von IFC Werkstatt
$AppId   = 'IFC-Werkstatt'
$AppName = 'IFC Werkstatt'
Add-Type -AssemblyName PresentationFramework
$answer = [System.Windows.MessageBox]::Show("$AppName wirklich entfernen?`n`nDeine eigenen Dateien (IFC, Excel) bleiben erhalten.", $AppName, 'YesNo', 'Question')
if ($answer -ne 'Yes') { exit 0 }
$Dest = Join-Path $env:LOCALAPPDATA ("Programs\" + $AppId)
foreach ($folder in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
  $lnk = Join-Path $folder ($AppName + '.lnk')
  if (Test-Path $lnk) { Remove-Item $lnk -Force -ErrorAction SilentlyContinue }
}
Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$AppId" -Recurse -Force -ErrorAction SilentlyContinue
Set-Location $env:TEMP
Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c timeout /t 2 /nobreak >nul & rmdir /s /q "' + $Dest + '"') -WindowStyle Hidden
[System.Windows.MessageBox]::Show("$AppName wurde entfernt.", $AppName, 'OK', 'Information') | Out-Null
