﻿# Installation von IFC Werkstatt (nur für den aktuellen Benutzer, keine Administratorrechte nötig)
$ErrorActionPreference = 'Stop'
$AppId   = 'IFC-Werkstatt'
$AppName = 'IFC Werkstatt'
$Html    = 'IFC-Werkstatt.html'
$Version = '1.32.0'

Add-Type -AssemblyName PresentationFramework
function Show-Info($text, $buttons = 'OK', $icon = 'Information') {
  return [System.Windows.MessageBox]::Show($text, $AppName, $buttons, $icon)
}

try {
  $Setup = $PSScriptRoot
  $Pkg   = Split-Path -Parent $Setup
  $AppSrc = Join-Path $Pkg 'app'
  if (-not (Test-Path (Join-Path $AppSrc $Html))) {
    Show-Info "Die Programmdateien wurden nicht gefunden.`n`nBitte die ZIP-Datei zuerst vollständig entpacken (Rechtsklick > Alle extrahieren) und dann 'Installieren (Windows).cmd' im entpackten Ordner starten." 'OK' 'Warning' | Out-Null
    exit 1
  }

  # 0. Schon installiert? Dann ist das ein Update – Daten (Ausmasse, Einstellungen) bleiben im Browser erhalten
  $key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$AppId"
  $Old = $null
  try { $Old = (Get-ItemProperty -Path $key -ErrorAction Stop).DisplayVersion } catch { }

  # 1. Dateien kopieren (vorhandene werden überschrieben)
  $Dest = Join-Path $env:LOCALAPPDATA ("Programs\" + $AppId)
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  Copy-Item -Path (Join-Path $AppSrc '*') -Destination $Dest -Recurse -Force
  Copy-Item -Path (Join-Path $Setup 'uninstall.ps1') -Destination $Dest -Force
  Get-ChildItem -Path $Dest -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

  # 2. Browser für das eigene Programmfenster suchen (Edge ist auf Windows 10/11 immer vorhanden)
  $candidates = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  $Browser = $null
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { $Browser = $c; break } }

  $HtmlPath = Join-Path $Dest $Html
  $Url  = ([System.Uri]$HtmlPath).AbsoluteUri
  $Icon = Join-Path $Dest 'icon.ico'

  # 3. Verknüpfungen
  $shell = New-Object -ComObject WScript.Shell
  function New-AppShortcut([string]$LinkPath) {
    $s = $shell.CreateShortcut($LinkPath)
    if ($Browser) {
      $s.TargetPath = $Browser
      $s.Arguments  = '--app="' + $Url + '"'
    } else {
      $s.TargetPath = $HtmlPath
    }
    $s.WorkingDirectory = $Dest
    $s.IconLocation = "$Icon,0"
    $s.Description = 'IFC-Modelle ansehen, attributieren und nach NPK-LV ausmessen, vollständig offline.'
    $s.Save()
  }
  $StartMenu = [Environment]::GetFolderPath('Programs')
  $Desktop   = [Environment]::GetFolderPath('Desktop')
  $LinkStart = Join-Path $StartMenu ($AppName + '.lnk')
  $LinkDesk  = Join-Path $Desktop ($AppName + '.lnk')
  New-AppShortcut $LinkStart
  New-AppShortcut $LinkDesk

  # 4. Eintrag unter "Apps & Features" (Deinstallation)
  $key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$AppId"
  New-Item -Path $key -Force | Out-Null
  $sizeKb = [int]((Get-ChildItem $Dest -Recurse -File | Measure-Object -Property Length -Sum).Sum / 1024)
  New-ItemProperty -Path $key -Name 'DisplayName'     -Value $AppName -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'DisplayVersion'  -Value $Version -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'Publisher'       -Value 'Eigene Werkzeuge' -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'DisplayIcon'     -Value $Icon -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'InstallLocation' -Value $Dest -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'UninstallString' -Value ('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Dest 'uninstall.ps1') + '"') -PropertyType String -Force | Out-Null
  New-ItemProperty -Path $key -Name 'NoModify'        -Value 1 -PropertyType DWord -Force | Out-Null
  New-ItemProperty -Path $key -Name 'NoRepair'        -Value 1 -PropertyType DWord -Force | Out-Null
  New-ItemProperty -Path $key -Name 'EstimatedSize'   -Value $sizeKb -PropertyType DWord -Force | Out-Null

  if ($Old) { $msg = "$AppName wurde von Version $Old auf $Version aktualisiert.`n`nDeine Ausmasse und Einstellungen bleiben erhalten.`n`nJetzt starten?" }
  else { $msg = "$AppName $Version wurde installiert.`n`nDu findest es im Startmenü und auf dem Desktop. Es läuft ohne Internet.`n`nJetzt starten?" }
  $answer = Show-Info $msg 'YesNo'
  if ($answer -eq 'Yes') { Start-Process -FilePath $LinkStart }
}
catch {
  Show-Info ("Die Installation ist fehlgeschlagen:`n`n" + $_.Exception.Message) 'OK' 'Error' | Out-Null
  exit 1
}
