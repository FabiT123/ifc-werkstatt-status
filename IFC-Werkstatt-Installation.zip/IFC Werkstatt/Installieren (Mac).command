#!/bin/bash
# Installation von IFC Werkstatt für macOS (nach ~/Applications)
set -e
cd "$(dirname "$0")"
APP="$HOME/Applications/IFC Werkstatt.app"
OLD=""
[ -f "$APP/Contents/Info.plist" ] && OLD="$(defaults read "$APP/Contents/Info" CFBundleShortVersionString 2>/dev/null || true)"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "app/IFC-Werkstatt.html" "$APP/Contents/Resources/"
cp "app/icon.icns" "$APP/Contents/Resources/icon.icns"
cat > "$APP/Contents/MacOS/start" <<'EOS'
#!/bin/bash
F="$(cd "$(dirname "$0")/../Resources" && pwd)/IFC-Werkstatt.html"
U="file://${F// /%20}"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$B.app" ] || [ -d "$HOME/Applications/$B.app" ]; then
    open -na "$B" --args --app="$U"
    exit 0
  fi
done
open "$F"
EOS
chmod +x "$APP/Contents/MacOS/start"
cat > "$APP/Contents/Info.plist" <<'EOS'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>IFC Werkstatt</string>
  <key>CFBundleDisplayName</key><string>IFC Werkstatt</string>
  <key>CFBundleIdentifier</key><string>local.werkzeuge.IFC-Werkstatt</string>
  <key>CFBundleVersion</key><string>1.34.1</string>
  <key>CFBundleShortVersionString</key><string>1.34.1</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>start</string>
  <key>CFBundleIconFile</key><string>icon</string>
</dict></plist>
EOS
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
echo ""
if [ -n "$OLD" ]; then echo "  IFC Werkstatt wurde von Version $OLD auf 1.34.1 aktualisiert (Daten bleiben erhalten)."; else echo "  IFC Werkstatt wurde nach ~/Applications installiert."; fi
echo "  Zum Entfernen den Ordner ~/Applications/IFC Werkstatt.app in den Papierkorb legen."
echo ""
open "$APP"
